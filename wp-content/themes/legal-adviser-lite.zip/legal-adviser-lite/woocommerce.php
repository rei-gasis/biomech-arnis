<?php get_header(); ?>
<div class="container">
    	<div class="pagefixer_legal">
			<?php woocommerce_content(); ?>
		</div><!-- pagefixer_legal -->
</div><!-- container -->     
<?php get_footer(); ?>